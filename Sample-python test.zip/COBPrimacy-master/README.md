# Docker instructions:

From Dockerfile directory

`docker build -t docker.optum.com/peds/cobprimacy:latest .`

From here we should be able to query the model by spinning up a docker image

`docker run -dp 6003:6003 docker.optum.com/peds/cobprimacy:latest`

 and ping it with, for example,

`curl -H "Content-Type: application/json" -X GET http://0.0.0.0:6003/cobprimacy/features`

# Development and testing:

There are a series of tests in the test/ directory.  These use the pyresttest tool, and we need to configure that first.

It seems necessary to get pyresttest directly from the git repo:
```
git clone https://github.com/svanoort/pyresttest.git
cd pyresttest
python setup.py install
```

From here, we can run tests by first spinning up a docker container, and then running pyresttest as follows:

`./run_tests.sh`

# OpenShift instructions:

To deploy to Openshift, first push the docker image to Docker Trusted Registry:

Log in to docker both in terminal and online at docker.optum.com

`docker login docker.optum.com`

Search for the peds organization, click on it and if not already there, create a repository

`docker tag docker.optum.com/peds/cobprimacy:latest docker.optum.com/peds/cobprimacy:latest`

`docker push docker.optum.com/peds/cobprimacy:latest`

The instructions from here presume you're logged into OpenShift.

If the imagestream, service, or route don't exist within openshift, create them as follows:

`oc process -f ose/auxConfig.yml $(sed "s/\(.*\)$/-v \1/g" ose/env.txt | tr '\n' ' ') | oc create -f -`

Increment the LatestVersion key in ose/deployConfig.yml and then deploy via

`oc process -f ose/deployConfig.yml -v $(sed "s/\(.*\)$/-v \1/g" ose/env.txt | tr '\n' ' ') | oc replace -f -`
