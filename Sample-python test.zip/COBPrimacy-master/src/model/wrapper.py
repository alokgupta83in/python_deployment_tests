import pickle
import pandas
import pandas as pd
import json
import numpy as np

class Wrapper():

  STATISTICAL_MODEL = pickle.load(open("./model/Model_v1.1.pkl", "rb"), encoding="latin1", fix_imports=True)
  #Without a spark context can't verify the exact order of features, putting them in anyways
  MODEL_FEATURES = ['OtherInsuranceMedicareCarrierName','EligibilityType','UHGPolicyType','OIExchangePolicy','OIPolicyType','HasCobra','IsRetiree','LongTermDisabilityDate','IndividualPlan','PartBCoordinationOfBenefitsEffectiveDate','PartACoordinationOfBenefitsEffectiveDate','PartDCoordinationOfBenefitsEffectiveDate','RetireeEffectiveDateLessThanMemberPolicyEffectiveEndDate','CobraEffectiveDateLessThanMemberPolicyEffectiveEndDate','GroupCountIndicator','IsUHGPolyEffectiveDateGreater','IsSubscriberDateOfBirthGreater','OIRelationship','UHGRelationship','Client','OICoordinationApplicable']

  def __init__(self, input_json, ident = None):
    self.id = input_json.pop('id', ident)
    input_df = pd.read_json(json.dumps([input_json]), orient = "records", numpy = True, encoding = "utf-8")
    self.input_values = self.__process_cob_input(input_df)

  def __process_cob_input(self,df):
    number_features = len(self.MODEL_FEATURES)
    if(df.shape[1] < number_features):
        raise ValueError
    values = pd.DataFrame([0]*(number_features)).transpose()
    for col_name in df.columns:
        values[self.MODEL_FEATURES.index(col_name)] = df[col_name][0]
    values.columns = self.MODEL_FEATURES
    return values

  def score(self):
    predictedvalue = self.STATISTICAL_MODEL.predict(self.input_values)
    return predictedvalue[0]

  #def prediction(self):
   # return self.score()

  #def predict_label(self):
  #  return ("Negative" if self.prediction() == 1 else "Positive")
