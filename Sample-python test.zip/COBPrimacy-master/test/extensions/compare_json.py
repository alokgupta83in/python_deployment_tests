import json

def json_eq(str_a, str_b):
  return json.loads(str_a) == json.loads(str_b)

def json_eq_file(str_a, file):
  with open(file) as data_file:
    json_contents = json.load(data_file)
  str_b = json.dumps(json_contents)
  return json_eq(str_a, str_b)

COMPARATORS = {'json_eq': json_eq, 'json_eq_file': json_eq_file}