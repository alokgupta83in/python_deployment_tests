import falcon
import logging
import controller.model
import controller.wellness_probe

with open("./logs/api_log.txt", "a") as file:
  pass

logging.basicConfig(filename='./logs/api_log.txt',format = '%(asctime)s %(levelname)s %(message)s', level=logging.DEBUG)
logging.basicConfig(filename='./logs/api_log.txt',format = '%(asctime)s %(levelname)s %(message)s', level=logging.INFO)

logging.debug('Starting server...')

app = falcon.API()

# TODO: fix route
app.add_route('/cobprimacy/{action}', controller.model.Controller())
app.add_route('/okcomputer', controller.wellness_probe.Controller())