import falcon

class Controller():
  def on_get(self, req, resp):
    resp.body = "Successful wellness probe"
    resp.status = falcon.HTTP_200