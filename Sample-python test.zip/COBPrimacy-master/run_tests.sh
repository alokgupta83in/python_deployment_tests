pyresttest --import_extensions 'test.extensions.compare_json' http://cobprimacyapi-cobwow-dev.ocp-ctc-core-nonprod.optum.com/cobprimacy test/fullsuite.yml
