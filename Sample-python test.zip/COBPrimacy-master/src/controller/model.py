import falcon
import logging
import json
import collections
from jinja2 import Template

import model.wrapper

class Controller():

	def on_get(self, req, resp, action):
		self.resp = resp
		self.resp.body, self.resp.status = RequestHandler().on_get(req, resp, action)

	def on_post(self, req, resp, action):
		self.resp = resp
		self.resp.body, self.resp.status = RequestHandler().on_post(req, resp, action)




def add_renderer(f):
  def method_with_rendering(self):
    f(self)
    return self.render(), falcon.HTTP_200
  return method_with_rendering

class RequestHandler():

  GET_ACTIONS  = ("steps", "features", "model_info", "class_labels", "data_source",
                  "performance_metrics")

  POST_ACTIONS = ('predict', 'batch_predict')

  def __preprocess(self, req, resp, action):
    body = req.stream.read()
    if body:
      self.json_input = json.loads(body)
    self.action = action
    self.resp = resp
    self.template_args = {}

  def on_get(self, req, resp, action):
    self.__preprocess(req, resp, action)
    logging.debug("GET {0} is started".format(self.action))
    if self.action in self.GET_ACTIONS:
      logging.info("Function: {0}".format(self.action))
      body, status = getattr(self, self.action)()
      logging.debug("{0} has ended".format(self.action))
      return body, status
    else:
      raise falcon.HTTPError(falcon.HTTP_400,'Invalid URL', 'Please provide a valid action')

  def on_post(self, req, resp, action):
    try:
      self.__preprocess(req, resp, action)
      if not hasattr(self,'json_input'):
        raise falcon.HTTPError(falcon.HTTP_400,'Empty body', 'Please provide a body with your request')
      logging.debug("POST {0} is started".format(self.action))
      if self.action in self.POST_ACTIONS:
        logging.info("Function: {0}".format(self.action))
        body, status = getattr(self, self.action)()
        logging.debug("{0} has ended".format(self.action))
        return body, status
      else:
        raise falcon.HTTPError(falcon.HTTP_400,'Invalid URL', 'Please provide a valid action')
    except ValueError:
      raise falcon.HTTPError(falcon.HTTP_400, 'Invalid request parameters', 'The predict action requires all features to be present')

  @add_renderer
  def steps(self):
    pass

  @add_renderer
  def features(self):
    pass

  @add_renderer
  def model_info(self):
    pass

  @add_renderer
  def class_labels(self):
    pass

  @add_renderer
  def data_source(self):
    pass

  @add_renderer
  def performance_metrics(self):
    pass

  @add_renderer
  def predict(self):
    predictive_model = model.wrapper.Wrapper(self.json_input['Record'])
    self.template_args = { "model": predictive_model }

  @add_renderer
  def batch_predict(self):
    all_inputs = self.json_input["Records"]
    predictive_models = map(lambda x: model.wrapper.Wrapper(x), all_inputs)
    self.template_args = { "models": predictive_models }

  def render(self):
    file_to_render = "view/{0}.json".format(self.action)
    with open(file_to_render) as file:
      template = Template(file.read())
    return json.dumps(json.loads(template.render(self.template_args)))
